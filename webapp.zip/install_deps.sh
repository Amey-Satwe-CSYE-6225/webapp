#!/bin/bash

sudo groupadd csye6225
sudo useradd -m -s /usr/sbin/nologin -g csye6225 csye6225


sudo cp /tmp/webapp-main.zip /opt/
cd /opt/

sudo yum makecache
sudo yum install unzip -y
sudo unzip webapp-main.zip
ls -ltr 

sudo chown -R csye6225:csye6225 ./webapp-main/
cd webapp-main
ls -ltr

sudo dnf install mysql-server

# To start the server
sudo systemctl start mysqld.service

sudo dnf module install nodejs:18/common

node -v

sudo cp ./node_server.service /etc/systemd/system/node_server.service

sudo systemctl daemon-reload

sudo systemtl enable node_server
